package pizzastore.ingredients;

public class Spinach implements Veggies {
    @Override
    public String toString() {
        return "Spinach";
    }
}